import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-exchange',
  templateUrl: './stock-exchange.component.html',
  styleUrls: ['./stock-exchange.component.css']
})
export class StockExchangeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
