import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  getCompanyList:boolean=false;
  rowData:any;

  constructor(private http:HttpClient) {
    
   }

   onClickSubmit(){
    this.rowData = this.http.get('http://localhost:8080/stockmarket-0.0.1-SNAPSHOT/company');
    this.getCompanyList=true;
   
   }

   OnRegister(postData){
    this.http.post('http://localhost:8080/stockmarket-0.0.1-SNAPSHOT/company',postData)
    .subscribe(posts=>{
      console.log(posts);
      console.log("Registered Success");
     
      this.onClickSubmit()
      alert("Registered Success")
      //this.router.navigate(['/']);
    })
  }
  ngOnInit() {  
  }

  columnDefs = [
    {headerName: 'Company  Name', field: 'companyname', sortable: true, filter: true,width: 100,editable: true},
    {headerName: 'Turn Over', field: 'turnover', sortable: true, filter: true,width: 100,editable: true},
    {headerName: 'Board of director', field: 'boardofdirec', sortable: true, filter: true,width: 100,editable: true},
    {headerName: 'Listed in stock', field: 'listedinstock', sortable: true, filter: true,width: 100,editable: true},
    {headerName: 'Sector', field: 'sector', sortable: true, filter: true,width: 100,editable: true},
    {headerName: 'About', field: 'about', sortable: true, filter: true,width: 100,editable: true},
    {headerName: 'Stockcode', field: 'stockcode', sortable: true, filter: true,width: 100,editable: true},
    {headerName: 'CEO', field: 'ceo', sortable: true, filter: true,width: 100,editable: true},
];

}
